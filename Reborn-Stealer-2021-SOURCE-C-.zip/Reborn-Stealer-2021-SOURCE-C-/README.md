# Reborn_Stealer_ChromeV80
 ☣️ Stealer chrome v81+, Firefox v75+, And more than 30 different programs and crypto-wallets 


❗️ Написан исключительно в образовательных целях! Я не несу ответственности за использование данного проекта и любых его частей кода.

❗️ Written exclusively for educational purposes! I am not responsible for the use of this project and any of its parts code.

Ну короче стиллер с отправкой логов в телеграм, достаточно хороший, похож по структуре на ешелон, но в принципе в основном только похож, расказать больше не чего, а ну поддержка Chrome v80+,Firefox v75+, стилит впн, криптокошельки, ваймворлд, стим, фтп, достает BSSID, токен и сессия дискорд, ну короче вы поняли

Donate || Донат (Помогите пж)
Payeer: P1035065489
Qiwi: 380992393528 
BTC: 1Ed1rHXnXtC8bo9CFMqCjn7dRnu8QLa27J
