﻿namespace Reborn
{
    public interface IFolders
    {
        string Source { get; }
        string Target { get; }
    }
}