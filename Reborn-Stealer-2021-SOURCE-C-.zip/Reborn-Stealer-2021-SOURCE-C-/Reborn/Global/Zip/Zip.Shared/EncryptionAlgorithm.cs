
namespace Ionic.Zip
{
  
    public enum EncryptionAlgorithm
    {

        None = 0,


        PkzipWeak,



        Unsupported = 4,


        // others... not implemented (yet?)
    }

}
